export interface APIResponse {
  statusCode: number
  body: string
}
